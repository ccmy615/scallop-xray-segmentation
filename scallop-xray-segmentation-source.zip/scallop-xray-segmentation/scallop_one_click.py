import argparse
import csv
import threading
from pathlib import Path

import cv2
import numpy as np
import segmentation_models_pytorch as smp
import torch


ROOT = Path(__file__).resolve().parent
MUSCLE_WEIGHTS = ROOT / "runs" / "muscle_binary_v1" / "model_best.pth"
JOINT_WEIGHTS = ROOT / "runs" / "unetpp_target_v2" / "model_best.pth"
COIN_AREA_MM2 = 490.87
SUPPORTED = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def read_image(path):
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise ValueError(f"无法读取图片：{path}")
    return image


def write_image(path, image):
    path.parent.mkdir(parents=True, exist_ok=True)
    extension = path.suffix if path.suffix else ".png"
    ok, encoded = cv2.imencode(extension, image)
    if not ok:
        raise ValueError(f"无法写入图片：{path}")
    encoded.tofile(str(path))


def largest_component(mask):
    binary = (mask > 0).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    if count <= 1:
        return binary
    keep = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return (labels == keep).astype(np.uint8)


class ScallopPredictor:
    def __init__(self):
        for checkpoint in (MUSCLE_WEIGHTS, JOINT_WEIGHTS):
            if not checkpoint.is_file():
                raise FileNotFoundError(f"Missing checkpoint: {checkpoint}. See docs/MODELS.md.")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.muscle_model = smp.UnetPlusPlus(
            encoder_name="resnet34", encoder_weights=None, in_channels=3, classes=2
        )
        self.muscle_model.load_state_dict(torch.load(MUSCLE_WEIGHTS, map_location="cpu"), strict=True)
        self.muscle_model.to(self.device).eval()
        self.joint_model = smp.UnetPlusPlus(
            encoder_name="resnet34", encoder_weights=None, in_channels=3, classes=3
        )
        self.joint_model.load_state_dict(torch.load(JOINT_WEIGHTS, map_location="cpu"), strict=True)
        self.joint_model.to(self.device).eval()

    def predict(self, original):
        resized = cv2.resize(original, (512, 512), interpolation=cv2.INTER_AREA)
        tensor = torch.from_numpy(resized.astype(np.float32) / 255.0).unsqueeze(0).repeat(3, 1, 1)
        tensor = ((tensor - 0.5) / 0.5).unsqueeze(0).to(self.device)
        with torch.no_grad():
            muscle_prob = torch.softmax(self.muscle_model(tensor), dim=1)[0, 1].cpu().numpy()
            joint_prob = torch.softmax(self.joint_model(tensor), dim=1)[0].cpu().numpy()
        muscle = largest_component(muscle_prob >= 0.5)
        coin = largest_component(joint_prob.argmax(0) == 2)
        muscle_pixels = int(muscle.sum())
        coin_pixels = int(coin.sum())
        area = muscle_pixels / max(coin_pixels, 1) * COIN_AREA_MM2
        muscle_confidence = float(muscle_prob[muscle > 0].mean()) if muscle_pixels else 0.0
        coin_confidence = float(joint_prob[2][coin > 0].mean()) if coin_pixels else 0.0
        warning = ""
        if muscle_pixels == 0 or coin_pixels == 0:
            warning = "未完整识别目标，请人工复核"
        elif muscle_confidence < 0.75:
            warning = "肉柱置信度偏低，请人工复核"
        height, width = original.shape
        muscle_full = cv2.resize(muscle, (width, height), interpolation=cv2.INTER_NEAREST)
        coin_full = cv2.resize(coin, (width, height), interpolation=cv2.INTER_NEAREST)
        return muscle_full, coin_full, area, muscle_confidence, coin_confidence, warning


def draw_visual(image, muscle, coin, area, warning):
    canvas = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    tint = canvas.copy()
    tint[muscle > 0] = (40, 210, 40)
    tint[coin > 0] = (30, 170, 255)
    canvas = cv2.addWeighted(canvas, 0.68, tint, 0.32, 0)
    scale = max(min(image.shape) / 512.0, 0.7)
    thickness = max(2, int(round(scale * 2)))
    for mask, color, label in ((muscle, (40, 255, 40), "muscle"), (coin, (0, 180, 255), "coin")):
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(canvas, contours, -1, color, thickness)
        if contours:
            x, y, _, _ = cv2.boundingRect(max(contours, key=cv2.contourArea))
            cv2.putText(canvas, label, (x, max(22, y - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.65 * scale, color, thickness)
    text = f"muscle area: {area:.2f} mm^2"
    cv2.rectangle(canvas, (5, 5), (int(330 * scale), int(40 * scale)), (0, 0, 0), -1)
    cv2.putText(canvas, text, (12, int(29 * scale)), cv2.FONT_HERSHEY_SIMPLEX, 0.62 * scale, (255, 255, 255), thickness)
    if warning:
        cv2.rectangle(canvas, (5, int(45 * scale)), (int(390 * scale), int(80 * scale)), (0, 0, 180), -1)
        cv2.putText(canvas, "LOW CONFIDENCE - REVIEW", (12, int(70 * scale)), cv2.FONT_HERSHEY_SIMPLEX, 0.55 * scale, (255, 255, 255), thickness)
    return canvas


def process_files(paths, output_dir, progress=None):
    if not paths:
        raise ValueError("No input images found.")
    stems = [path.stem for path in paths]
    if len(stems) != len(set(stems)):
        raise ValueError("Input image stems must be unique to prevent output overwrites.")
    predictor = ScallopPredictor()
    output_dir.mkdir(parents=True, exist_ok=True)
    visuals_dir = output_dir / "visuals"
    masks_dir = output_dir / "masks"
    rows = []
    for index, path in enumerate(paths, start=1):
        image = read_image(path)
        muscle, coin, area, muscle_conf, coin_conf, warning = predictor.predict(image)
        visual = draw_visual(image, muscle, coin, area, warning)
        write_image(visuals_dir / f"{path.stem}_result.png", visual)
        write_image(masks_dir / f"{path.stem}_muscle.png", muscle * 255)
        write_image(masks_dir / f"{path.stem}_coin.png", coin * 255)
        rows.append({
            "file": path.name,
            "muscle_area_mm2": round(area, 4),
            "muscle_confidence": round(muscle_conf, 4),
            "coin_confidence": round(coin_conf, 4),
            "warning": warning,
        })
        if progress:
            progress(index, len(paths), path.name)
    with (output_dir / "results.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    return rows


def launch_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    window = tk.Tk()
    window.title("扇贝X光肉柱面积识别")
    window.geometry("620x260")
    selected = []
    status = tk.StringVar(value="请选择图片，然后点击开始识别")

    def choose():
        files = filedialog.askopenfilenames(
            title="选择扇贝X光图片",
            filetypes=[("图片", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff")],
        )
        selected.clear()
        selected.extend(Path(item) for item in files)
        status.set(f"已选择 {len(selected)} 张图片")

    def start():
        if not selected:
            messagebox.showwarning("提示", "请先选择图片")
            return
        folder = filedialog.askdirectory(title="选择结果保存文件夹")
        if not folder:
            return
        button_start.config(state="disabled")

        def update(done, total, name):
            window.after(0, lambda: (bar.configure(value=done / total * 100), status.set(f"处理中 {done}/{total}：{name}")))

        def worker():
            try:
                process_files(selected, Path(folder), update)
                window.after(0, lambda: messagebox.showinfo("完成", f"识别完成，结果已保存到：\n{folder}"))
                window.after(0, lambda: status.set("处理完成：已生成核对图、掩码和面积表"))
            except Exception as exc:
                window.after(0, lambda error=str(exc): messagebox.showerror("处理失败", error))
            finally:
                window.after(0, lambda: button_start.config(state="normal"))

        threading.Thread(target=worker, daemon=True).start()

    ttk.Label(window, text="扇贝X光肉柱与硬币自动识别", font=("Microsoft YaHei UI", 16, "bold")).pack(pady=(24, 10))
    ttk.Label(window, text="输出：轮廓核对图、黑白掩码、肉柱面积(mm²)、置信度提示").pack(pady=5)
    row = ttk.Frame(window)
    row.pack(pady=18)
    ttk.Button(row, text="1. 选择图片", command=choose, width=20).pack(side="left", padx=8)
    button_start = ttk.Button(row, text="2. 开始识别", command=start, width=20)
    button_start.pack(side="left", padx=8)
    bar = ttk.Progressbar(window, length=500, mode="determinate")
    bar.pack(pady=5)
    ttk.Label(window, textvariable=status).pack(pady=6)
    window.mainloop()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("images", nargs="*", type=Path)
    parser.add_argument("--input-dir", type=Path)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    paths = list(args.images)
    if args.input_dir:
        paths.extend(path for path in sorted(args.input_dir.iterdir()) if path.suffix.lower() in SUPPORTED)
    if not paths:
        if args.input_dir:
            parser.error("No supported images found in --input-dir.")
        launch_gui()
        return
    rows = process_files(paths, args.output_dir)
    print(f"完成：{len(rows)} 张，结果位于 {args.output_dir}")


if __name__ == "__main__":
    main()
