# Scallop X-ray Segmentation

## 扇贝X光肉柱自动分割与面积测量

从X光图像中分割肉柱和硬币，以硬币的已知面积完成尺度标定，批量输出预测轮廓、黑白掩码及肉柱面积。项目包含五种模型的训练、评估代码与实验记录，最终应用采用两份 U-Net++ 权重。

![独立测试集4号样本的预测效果](docs/images/prediction.png)

绿色：肉柱；橙色：硬币。该示例的人工肉柱面积为224.36 mm²，预测面积203.73 mm²，Dice为0.9269。图像来自独立测试集，示例效果不代表所有样本。

## 模型与结果

| 肉柱模型 | 骨干网络 | 全50张平均Dice | 48张敏感性平均Dice | 全50张平均面积相对误差 |
|---|---|---:|---:|---:|
| U-Net++ | ResNet34 | 0.8910 | 0.9215 | 11.10% |
| U-Net | ResNet34 | 0.8683 | 0.8898 | 17.68% |
| DeepLabV3+ | ResNet34 | 0.8909 | 0.9103 | 14.06% |
| SegFormer-B0 | MiT-B0 | 0.8625 | 0.8809 | 17.52% |
| Mask R-CNN（Detectron2） | ResNet50-FPN | 0.8930 | 0.9108 | 13.82% |

所有模型共用固定的 U-Net++ 硬币模型。最终肉柱模型选择 U-Net++，本次全量测试中其平均面积误差最低。硬币平均Dice为0.9822。48张结果排除人工确认的1号和10号困难样本，仅作敏感性分析；它不证明模型在被排除样本上更稳定，也不替代全50张结果。

数据划分：源域257张（200训练 / 29验证 / 28测试）；第一批目标域50张（40训练 / 10验证）；第二批50张用于独立测试。原始完整数据集未包含在本仓库。数据根目录可在 `configs/splits_v1.json` 配置，具体布局见 [数据与评价口径](docs/DATA_AND_PROTOCOL.md)。

## 安装

已核验的本地环境为 Python 3.9.23、PyTorch 2.0.1、torchvision 0.15.2、CUDA 11.8；完整记录在 `docs/environment_snapshot.json`。这是历史可运行环境，新系统需自行验证兼容性。

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux: source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install torch==2.0.1 torchvision==0.15.2 --index-url https://download.pytorch.org/whl/cu118
python -m pip install -r requirements.txt
```

仅需CPU时，将PyTorch安装命令中的源换为 `https://download.pytorch.org/whl/cpu`。图形界面使用Tkinter；无桌面环境请使用命令行。

Detectron2仅在运行对应训练、评估和五模型速度汇总时需要。已有环境版本为0.6，需与PyTorch/CUDA及编译工具匹配；安装入口见 [Detectron2官方项目](https://github.com/facebookresearch/detectron2)。本仓库未复制第三方框架源码。

## 快速识别

先按 [模型权重说明](docs/MODELS.md) 放置两份最终权重。权重不随Git源码包提交；当前未设置公开下载地址。

```bash
python tools/check_project.py --check-weights
python scallop_one_click.py --input-dir examples/input --output-dir results/demo
```

无参数运行 `python scallop_one_click.py` 打开界面；Windows也可在已激活环境中运行 `launch_app.bat`。

输出：`visuals/*_result.png`、`masks/*_muscle.png`、`masks/*_coin.png`、`results.csv`。

面积（mm²）= 肉柱像素数 / 硬币像素数 × 490.87。计算采用512×512分割结果，显示掩码恢复为原图尺寸。硬币与目标须位于同一平面。低置信度提示是人工复核线索，不是经过校准的错误概率；未检出硬币时的面积不可作为有效测量。

## 训练与评估

配置完整数据和初始化权重后，可用整理好的实验配置启动训练：

```bash
python tools/reproduce_train.py --run muscle_binary_v1 --dry-run
python tools/reproduce_train.py --run muscle_binary_v1
python tools/reproduce_train.py --run unetpp_target_v2
python tools/reproduce_train.py --run comparison_unet_v1
python tools/reproduce_train.py --run comparison_deeplabv3plus_v1
python tools/reproduce_train.py --run comparison_segformer_b0_v1
python tools/reproduce_train.py --run comparison_detectron2_v1
```

新训练结果默认保存在 `outputs/<run>`，不会覆盖随仓库附带的历史记录。`--dry-run` 只打印命令。源域初始化权重是复现U-Net++等历史实验的必要输入；其最初预训练过程未整理为可确认的逐步复现流程，因此当前仓库从该权重开始复现目标域适配。

独立测试示例（使用已经冻结的模型）：

```bash
python evaluate_blind2.py --output-dir outputs/eval_unetpp
python evaluate_blind2.py --muscle-architecture unet --muscle-weights runs/comparison_unet_v1/model_best.pth --output-dir outputs/eval_unet
python evaluate_blind2.py --muscle-architecture deeplabv3plus --muscle-weights runs/comparison_deeplabv3plus_v1/model_best.pth --output-dir outputs/eval_deeplab
python evaluate_blind2.py --muscle-architecture segformer_b0 --muscle-weights runs/comparison_segformer_b0_v1/model_best.pth --output-dir outputs/eval_segformer
python evaluate_detectron2_blind2.py --output-dir outputs/eval_detectron2
```

训练和离线评估数据应预处理为512×512；一键推理程序可自动缩放新图片。随机种子固定不保证不同硬件和依赖下逐位一致。既有测试结果已经用于模型比较，后续调参后的模型需要新的外部测试集。

## 文件导航

| 文件 | 用途 |
|---|---|
| `train_unetpp_target.py` | U-Net、U-Net++、DeepLabV3+、SegFormer-B0；联合增强、CE+Dice、混合精度、早停 |
| `train_detectron2_target.py` | 单类别Mask R-CNN训练与验证 |
| `evaluate_blind2.py` | 四类语义分割的逐图Dice、IoU、面积误差及敏感性分析 |
| `evaluate_detectron2_blind2.py` | Mask R-CNN独立评估 |
| `scallop_one_click.py` | 最终双模型命令行 / 图形界面 |
| `summarize_model_comparison.py` | 读取历史结果并重新计时；需全部模型、数据及Detectron2 |
| `project_config.py` | 与工作目录无关的数据路径解析 |
| `configs/` | 固定划分、困难样本记录和权重SHA-256清单 |
| `runs/` | 历史训练配置、日志、评价JSON和逐图CSV，无模型二进制文件 |
| `tools/` | 环境/文件检查、训练复现入口 |
| `examples/` | 一个真实测试图像及人工标注 |

项目开发内容与第三方架构边界见 [代码说明](docs/CODE_MAP.md)。上传方法见 [GitHub上传说明](docs/GITHUB_UPLOAD.md)。

## 使用范围与依赖来源

本项目为科研原型，未验证对任意手机、拍摄条件和新批次的泛化能力。第三方模型由 [Segmentation Models PyTorch](https://github.com/qubvel-org/segmentation_models.pytorch)、[timm](https://github.com/huggingface/pytorch-image-models)、[Detectron2](https://github.com/facebookresearch/detectron2) 提供，分别遵循其上游许可。项目自身尚未指定开源许可证，仓库公开与明确授权再分发是不同事项。
