import argparse
import json
import math
import random
import time
from pathlib import Path
from project_config import load_splits

import cv2
import numpy as np
import segmentation_models_pytorch as smp
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset


PROJECT_ROOT = Path(__file__).resolve().parent
DEFAULT_SPLITS = PROJECT_ROOT / "configs" / "splits_v1.json"
DEFAULT_INITIAL_WEIGHTS = None


def build_model(architecture, num_classes, encoder_weights=None):
    if architecture == "unet":
        return smp.Unet(
            encoder_name="resnet34", encoder_weights=encoder_weights, in_channels=3, classes=num_classes
        )
    if architecture == "unetplusplus":
        return smp.UnetPlusPlus(
            encoder_name="resnet34", encoder_weights=encoder_weights, in_channels=3, classes=num_classes
        )
    if architecture == "deeplabv3plus":
        return smp.DeepLabV3Plus(
            encoder_name="resnet34", encoder_weights=encoder_weights, in_channels=3, classes=num_classes
        )
    if architecture == "segformer_b0":
        return smp.Segformer(
            encoder_name="mit_b0", encoder_weights=encoder_weights, in_channels=3, classes=num_classes
        )
    raise ValueError(f"Unsupported architecture: {architecture}")


def read_gray(path: Path):
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(path)
    return image


def largest_component(mask: np.ndarray):
    binary = (mask > 0).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    if count <= 1:
        return binary
    index = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return (labels == index).astype(np.uint8)


def load_example(dataset_name, root: Path, stem: str):
    if dataset_name == "source":
        image_path = root / "all_images" / f"{stem}.png"
        muscle_path = root / "all_mmask" / f"{stem}.png"
        coin_path = root / "all_cmask" / f"{stem}.png"
    else:
        image_path = root / "50" / f"{stem}.png"
        muscle_path = root / "mmask" / f"{stem}.png"
        coin_path = root / "cmask" / f"{stem}.png"
    image = read_gray(image_path)
    muscle = largest_component(read_gray(muscle_path))
    coin = largest_component(read_gray(coin_path))
    return image, muscle, coin


class JointAugment:
    def __init__(self, enabled=True):
        self.enabled = enabled

    def __call__(self, image, muscle, coin):
        if not self.enabled:
            return image, muscle, coin

        if random.random() < 0.5:
            image, muscle, coin = np.fliplr(image), np.fliplr(muscle), np.fliplr(coin)
        if random.random() < 0.5:
            image, muscle, coin = np.flipud(image), np.flipud(muscle), np.flipud(coin)
        if random.random() < 0.75:
            rotations = random.randint(0, 3)
            image = np.rot90(image, rotations)
            muscle = np.rot90(muscle, rotations)
            coin = np.rot90(coin, rotations)

        if random.random() < 0.85:
            height, width = image.shape
            angle = random.uniform(-25.0, 25.0)
            scale = random.uniform(0.78, 1.22)
            translate_x = random.uniform(-0.16, 0.16) * width
            translate_y = random.uniform(-0.16, 0.16) * height
            matrix = cv2.getRotationMatrix2D((width / 2.0, height / 2.0), angle, scale)
            matrix[:, 2] += [translate_x, translate_y]
            image = cv2.warpAffine(
                image,
                matrix,
                (width, height),
                flags=cv2.INTER_LINEAR,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=255,
            )
            muscle = cv2.warpAffine(
                muscle,
                matrix,
                (width, height),
                flags=cv2.INTER_NEAREST,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=0,
            )
            coin = cv2.warpAffine(
                coin,
                matrix,
                (width, height),
                flags=cv2.INTER_NEAREST,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=0,
            )

        float_image = image.astype(np.float32) / 255.0
        if random.random() < 0.8:
            contrast = random.uniform(0.72, 1.30)
            brightness = random.uniform(-0.12, 0.12)
            float_image = (float_image - 0.5) * contrast + 0.5 + brightness
        if random.random() < 0.55:
            gamma = random.uniform(0.65, 1.45)
            float_image = np.clip(float_image, 0.0, 1.0) ** gamma
        if random.random() < 0.35:
            sigma = random.uniform(0.003, 0.025)
            float_image += np.random.normal(0.0, sigma, float_image.shape).astype(np.float32)
        if random.random() < 0.25:
            kernel = random.choice([3, 5])
            float_image = cv2.GaussianBlur(float_image, (kernel, kernel), random.uniform(0.2, 1.2))
        if random.random() < 0.35:
            height, width = float_image.shape
            axis_length = width if random.random() < 0.5 else height
            coordinate = np.arange(axis_length, dtype=np.float32)
            period = random.uniform(2.2, 8.0)
            amplitude = random.uniform(0.008, 0.035)
            stripe = amplitude * np.sin(2.0 * math.pi * coordinate / period + random.uniform(0, 2 * math.pi))
            stripe = stripe[None, :] if axis_length == width else stripe[:, None]
            float_image += stripe

        image = np.clip(float_image * 255.0, 0, 255).astype(np.uint8)
        return np.ascontiguousarray(image), np.ascontiguousarray(muscle), np.ascontiguousarray(coin)


class ScallopDataset(Dataset):
    def __init__(self, entries, augment=False, task="joint"):
        self.entries = entries
        self.augment = JointAugment(augment)
        self.task = task

    def __len__(self):
        return len(self.entries)

    def __getitem__(self, index):
        dataset_name, root, stem = self.entries[index]
        image, muscle, coin = load_example(dataset_name, root, stem)
        image, muscle, coin = self.augment(image, muscle, coin)

        target = np.zeros(image.shape, dtype=np.int64)
        target[muscle > 0] = 1
        if self.task == "joint":
            target[coin > 0] = 2

        tensor = torch.from_numpy(image.astype(np.float32) / 255.0).unsqueeze(0)
        tensor = tensor.repeat(3, 1, 1)
        tensor = (tensor - 0.5) / 0.5
        return tensor, torch.from_numpy(target), f"{dataset_name}:{stem}"


def soft_dice_loss(logits, target):
    probabilities = torch.softmax(logits, dim=1)
    one_hot = F.one_hot(target, num_classes=logits.shape[1]).permute(0, 3, 1, 2).float()
    intersection = (probabilities[:, 1:] * one_hot[:, 1:]).sum(dim=(0, 2, 3))
    denominator = (probabilities[:, 1:] + one_hot[:, 1:]).sum(dim=(0, 2, 3))
    dice = (2.0 * intersection + 1.0) / (denominator + 1.0)
    return 1.0 - dice.mean()


def per_image_metrics(prediction, target, coin_area_mm2, task="joint"):
    rows = []
    for pred, truth in zip(prediction, target):
        row = {}
        classes = ((1, "muscle"), (2, "coin")) if task == "joint" else ((1, "muscle"),)
        for class_id, label in classes:
            pred_class = pred == class_id
            truth_class = truth == class_id
            intersection = (pred_class & truth_class).sum().item()
            pred_count = pred_class.sum().item()
            truth_count = truth_class.sum().item()
            union = pred_count + truth_count - intersection
            row[f"{label}_dice"] = (2.0 * intersection) / max(pred_count + truth_count, 1)
            row[f"{label}_iou"] = intersection / max(union, 1)
            row[f"{label}_pixels_pred"] = pred_count
            row[f"{label}_pixels_true"] = truth_count
        if task == "joint":
            true_area = row["muscle_pixels_true"] / max(row["coin_pixels_true"], 1) * coin_area_mm2
            predicted_area = row["muscle_pixels_pred"] / max(row["coin_pixels_pred"], 1) * coin_area_mm2
            row["area_true_mm2"] = true_area
            row["area_pred_mm2"] = predicted_area
            row["area_absolute_error_mm2"] = abs(predicted_area - true_area)
            row["area_relative_error"] = abs(predicted_area - true_area) / max(true_area, 1e-8)
        rows.append(row)
    return rows


def evaluate(model, loader, device, coin_area_mm2, task="joint"):
    model.eval()
    rows = []
    with torch.no_grad():
        for images, targets, identifiers in loader:
            images = images.to(device, non_blocking=True)
            logits = model(images)
            predictions = logits.argmax(dim=1).cpu()
            batch_rows = per_image_metrics(predictions, targets, coin_area_mm2, task=task)
            for identifier, row in zip(identifiers, batch_rows):
                row["id"] = identifier
                rows.append(row)
    summary = {}
    keys = ("muscle_dice", "muscle_iou")
    if task == "joint":
        keys += ("coin_dice", "coin_iou", "area_absolute_error_mm2", "area_relative_error")
    for key in keys:
        values = np.asarray([row[key] for row in rows], dtype=np.float64)
        summary[f"{key}_mean"] = float(values.mean())
        summary[f"{key}_median"] = float(np.median(values))
        summary[f"{key}_p95"] = float(np.quantile(values, 0.95))
    return summary, rows


def entries_from_split(split_config):
    source_root = Path(split_config["source"]["root"])
    target_root = Path(split_config["target1"]["root"])
    source_train = [("source", source_root, stem) for stem in split_config["source"]["train"]]
    source_val = [("source", source_root, stem) for stem in split_config["source"]["val"]]
    source_test = [("source", source_root, stem) for stem in split_config["source"]["test"]]
    target_train = [("target1", target_root, stem) for stem in split_config["target1"]["train"]]
    target_val = [("target1", target_root, stem) for stem in split_config["target1"]["val"]]
    return source_train, source_val, source_test, target_train, target_val


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--splits", type=Path, default=DEFAULT_SPLITS)
    parser.add_argument("--output-dir", type=Path, default=PROJECT_ROOT / "runs" / "experiment_new")
    parser.add_argument("--initial-weights", type=Path, default=DEFAULT_INITIAL_WEIGHTS)
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=20260906)
    parser.add_argument("--source-only", action="store_true")
    parser.add_argument(
        "--target-repeat",
        type=int,
        default=1,
        help="Repeat target-domain training records to reduce source-domain dominance.",
    )
    parser.add_argument("--background-weight", type=float, default=1.0)
    parser.add_argument("--muscle-weight", type=float, default=1.0)
    parser.add_argument("--coin-weight", type=float, default=1.0)
    parser.add_argument("--task", choices=("joint", "muscle"), default="joint")
    parser.add_argument(
        "--architecture",
        choices=("unet", "unetplusplus", "deeplabv3plus", "segformer_b0"),
        default="unetplusplus",
    )
    parser.add_argument("--encoder-weights", choices=("none", "imagenet"), default="none")
    parser.add_argument(
        "--initialization-scope",
        choices=("compatible", "encoder", "strict"),
        default="compatible",
        help="Controls which parameters are restored from --initial-weights.",
    )
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)

    split_config = load_splits(args.splits)
    coin_area_mm2 = float(split_config["coin_area_mm2"])
    source_train, source_val, source_test, target_train, target_val = entries_from_split(split_config)
    if args.target_repeat < 1:
        raise ValueError("--target-repeat must be at least 1")
    train_entries = source_train if args.source_only else source_train + target_train * args.target_repeat

    train_loader = DataLoader(
        ScallopDataset(train_entries, augment=True, task=args.task),
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True,
    )
    source_val_loader = DataLoader(ScallopDataset(source_val, task=args.task), batch_size=args.batch_size, shuffle=False)
    target_val_loader = DataLoader(ScallopDataset(target_val, task=args.task), batch_size=args.batch_size, shuffle=False)
    source_test_loader = DataLoader(ScallopDataset(source_test, task=args.task), batch_size=args.batch_size, shuffle=False)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    num_classes = 3 if args.task == "joint" else 2
    model = build_model(
        args.architecture,
        num_classes,
        encoder_weights=None if args.encoder_weights == "none" else args.encoder_weights,
    )
    initialization_report = {
        "source": None,
        "scope": args.initialization_scope,
        "loaded_tensors": 0,
        "model_tensors": len(model.state_dict()),
    }
    if args.initial_weights and not args.initial_weights.is_file():
        raise FileNotFoundError(f"Initial checkpoint not found: {args.initial_weights}")
    if args.initial_weights:
        initial_state = torch.load(args.initial_weights, map_location="cpu")
        initialization_report["source"] = str(args.initial_weights)
        if args.initialization_scope == "strict":
            model.load_state_dict(initial_state, strict=True)
            initialization_report["loaded_tensors"] = len(initial_state)
        else:
            current_state = model.state_dict()
            compatible_state = {
                key: value
                for key, value in initial_state.items()
                if key in current_state
                and current_state[key].shape == value.shape
                and (args.initialization_scope == "compatible" or key.startswith("encoder."))
            }
            model.load_state_dict(compatible_state, strict=False)
            initialization_report["loaded_tensors"] = len(compatible_state)
            if not compatible_state:
                raise RuntimeError(
                    f"No compatible tensors found in {args.initial_weights} for {args.architecture}. "
                    "Use a compatible checkpoint or omit --initial-weights when using --encoder-weights."
                )
    model.to(device)

    weights = [args.background_weight, args.muscle_weight]
    if args.task == "joint":
        weights.append(args.coin_weight)
    class_weights = torch.tensor(
        weights,
        dtype=torch.float32,
        device=device,
    )

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", factor=0.5, patience=3)
    scaler = torch.cuda.amp.GradScaler(enabled=device.type == "cuda")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    history_path = args.output_dir / "history.jsonl"
    best_path = args.output_dir / "model_best.pth"
    last_path = args.output_dir / "model_last.pth"
    best_score = -1.0
    stale_epochs = 0

    with history_path.open("w", encoding="utf-8") as history_file:
        for epoch in range(1, args.epochs + 1):
            started = time.time()
            model.train()
            losses = []
            for images, targets, _ in train_loader:
                images = images.to(device, non_blocking=True)
                targets = targets.to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                with torch.cuda.amp.autocast(enabled=device.type == "cuda"):
                    logits = model(images)
                    cross_entropy = F.cross_entropy(logits, targets, weight=class_weights)
                    dice_loss = soft_dice_loss(logits, targets)
                    loss = cross_entropy + dice_loss
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                scaler.step(optimizer)
                scaler.update()
                losses.append(float(loss.item()))

            source_summary, _ = evaluate(model, source_val_loader, device, coin_area_mm2, task=args.task)
            target_summary, _ = evaluate(model, target_val_loader, device, coin_area_mm2, task=args.task)
            selection_score = target_summary["muscle_dice_mean"] if not args.source_only else source_summary["muscle_dice_mean"]
            scheduler.step(selection_score)
            record = {
                "epoch": epoch,
                "train_loss": float(np.mean(losses)),
                "learning_rate": optimizer.param_groups[0]["lr"],
                "selection_score": selection_score,
                "source_val": source_summary,
                "target_val": target_summary,
                "elapsed_seconds": time.time() - started,
            }
            history_file.write(json.dumps(record, ensure_ascii=False) + "\n")
            history_file.flush()
            print(json.dumps(record, ensure_ascii=False), flush=True)

            if selection_score > best_score + 1e-5:
                best_score = selection_score
                stale_epochs = 0
                torch.save(model.state_dict(), best_path)
            else:
                stale_epochs += 1
            if stale_epochs >= args.patience:
                break

    torch.save(model.state_dict(), last_path)
    model.load_state_dict(torch.load(best_path, map_location=device), strict=True)
    source_test_summary, source_test_rows = evaluate(
        model, source_test_loader, device, coin_area_mm2, task=args.task
    )
    target_val_summary, target_val_rows = evaluate(
        model, target_val_loader, device, coin_area_mm2, task=args.task
    )
    final_report = {
        "architecture": args.architecture,
        "initialization": initialization_report,
        "best_selection_score": best_score,
        "source_test": source_test_summary,
        "target1_validation": target_val_summary,
        "source_test_rows": source_test_rows,
        "target1_validation_rows": target_val_rows,
        "blind2_evaluated": False,
    }
    (args.output_dir / "evaluation.json").write_text(
        json.dumps(final_report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (args.output_dir / "run_config.json").write_text(
        json.dumps(vars(args), default=str, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(final_report, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
