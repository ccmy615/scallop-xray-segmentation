import csv
import json
import time
from pathlib import Path
from project_config import load_splits

import numpy as np
import torch

from evaluate_blind2 import make_tensor, read_gray
from train_unetpp_target import build_model


PROJECT_ROOT = Path(__file__).resolve().parent
SPLITS = PROJECT_ROOT / "configs" / "splits_v1.json"
OUTPUT_CSV = PROJECT_ROOT / "runs" / "model_comparison_v1.csv"
OUTPUT_JSON = PROJECT_ROOT / "runs" / "model_comparison_v1.json"

MODELS = [
    {
        "name": "U-Net++",
        "architecture": "unetplusplus",
        "run": PROJECT_ROOT / "runs" / "muscle_binary_v1",
        "blind": PROJECT_ROOT / "runs" / "blind2_final_v1",
    },
    {
        "name": "U-Net",
        "architecture": "unet",
        "run": PROJECT_ROOT / "runs" / "comparison_unet_v1",
        "blind": PROJECT_ROOT / "runs" / "comparison_unet_v1" / "blind2",
    },
    {
        "name": "DeepLabV3+",
        "architecture": "deeplabv3plus",
        "run": PROJECT_ROOT / "runs" / "comparison_deeplabv3plus_v1",
        "blind": PROJECT_ROOT / "runs" / "comparison_deeplabv3plus_v1" / "blind2",
    },
    {
        "name": "SegFormer-B0",
        "architecture": "segformer_b0",
        "run": PROJECT_ROOT / "runs" / "comparison_segformer_b0_v1",
        "blind": PROJECT_ROOT / "runs" / "comparison_segformer_b0_v1" / "blind2",
    },
    {
        "name": "Detectron2 Mask R-CNN",
        "architecture": "detectron2_mask_rcnn_r50_fpn",
        "run": PROJECT_ROOT / "runs" / "comparison_detectron2_v1",
        "blind": PROJECT_ROOT / "runs" / "comparison_detectron2_v1" / "blind2",
    },
]


def benchmark(model, tensors, device):
    model.eval()
    with torch.no_grad():
        for _ in range(3):
            model(tensors[0])
        if device.type == "cuda":
            torch.cuda.synchronize()
        times = []
        for tensor in tensors:
            started = time.perf_counter()
            model(tensor)
            if device.type == "cuda":
                torch.cuda.synchronize()
            times.append((time.perf_counter() - started) * 1000.0)
    return {
        "mean_ms": float(np.mean(times)),
        "median_ms": float(np.median(times)),
        "p95_ms": float(np.quantile(times, 0.95)),
    }


def main():
    config = load_splits(SPLITS)
    blind_root = Path(config["blind2"]["root"])
    stems = config["blind2"]["locked_test"]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tensors = [make_tensor(read_gray(blind_root / "50X图" / f"{stem}.png"), device) for stem in stems]

    joint = build_model("unetplusplus", 3, encoder_weights=None)
    joint.load_state_dict(
        torch.load(PROJECT_ROOT / "runs" / "unetpp_target_v2" / "model_best.pth", map_location="cpu"),
        strict=True,
    )
    joint.to(device)
    coin_speed = benchmark(joint, tensors, device)
    del joint

    rows = []
    for spec in MODELS:
        training = json.loads((spec["run"] / "evaluation.json").read_text(encoding="utf-8"))
        blind = json.loads((spec["blind"] / "summary.json").read_text(encoding="utf-8"))
        checkpoint = spec["run"] / "model_best.pth"
        if spec["architecture"] == "detectron2_mask_rcnn_r50_fpn":
            from detectron2.modeling import build_model as build_detectron_model
            from train_detectron2_target import make_cfg

            model = build_detectron_model(make_cfg(device, 0.5))
            model.load_state_dict(torch.load(checkpoint, map_location="cpu"), strict=True)
            parameters = sum(parameter.numel() for parameter in model.parameters())
            muscle_speed = {
                "mean_ms": blind["muscle_inference_ms"]["mean"],
                "median_ms": blind["muscle_inference_ms"]["median"],
                "p95_ms": blind["muscle_inference_ms"]["p95"],
            }
            del model
        else:
            model = build_model(spec["architecture"], 2, encoder_weights=None)
            model.load_state_dict(torch.load(checkpoint, map_location="cpu"), strict=True)
            parameters = sum(parameter.numel() for parameter in model.parameters())
            model.to(device)
            muscle_speed = benchmark(model, tensors, device)
            del model
        if device.type == "cuda":
            torch.cuda.empty_cache()
        rows.append(
            {
                "model": spec["name"],
                "architecture": spec["architecture"],
                "target1_val_dice": training["target1_validation"]["muscle_dice_mean"],
                "source_test_dice": training["source_test"]["muscle_dice_mean"],
                "blind50_muscle_dice": blind["muscle_dice"]["mean"],
                "blind50_muscle_dice_median": blind["muscle_dice"]["median"],
                "blind48_sensitivity_dice": blind["sensitivity_analysis"]["muscle_dice"]["mean"],
                "blind50_area_relative_error": blind["area_relative_error"]["mean"],
                "blind50_area_absolute_error_mm2": blind["area_absolute_error_mm2"]["mean"],
                "blind48_area_relative_error": blind["sensitivity_analysis"]["area_relative_error"]["mean"],
                "muscle_inference_mean_ms": muscle_speed["mean_ms"],
                "estimated_full_pipeline_mean_ms": muscle_speed["mean_ms"] + coin_speed["mean_ms"],
                "parameters": parameters,
                "checkpoint_mb": checkpoint.stat().st_size / (1024 * 1024),
            }
        )

    fieldnames = list(rows[0].keys())
    with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    report = {
        "protocol": {
            "development": "same split, seed, 512x512 input, target repetition, learning rate, epoch cap and early-stopping rule; each architecture uses its native loss and standard compatible pretraining",
            "blind_test": "locked second batch of 50 images; no threshold or checkpoint tuning",
            "sensitivity": "IDs 1 and 10 excluded only in the separately reported difficult-case sensitivity analysis",
            "coin_model": "fixed U-Net++ coin model for every row",
            "speed_device": str(device),
            "fixed_coin_inference": coin_speed,
        },
        "rows": rows,
        "recommended_operational_model": "U-Net++",
        "selection_reason": "best mean area relative error and best difficult-case sensitivity Dice; Detectron2 has slightly higher all-50 Dice but is weaker on area error, sensitivity analysis and speed",
    }
    OUTPUT_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
