@echo off
cd /d "%~dp0"
python scallop_one_click.py
pause
