# 本地整理验证

验证日期：2026-09-17。使用 `docs/environment_snapshot.json` 所列环境。

- 七份权重复制后SHA-256校验通过。
- 固定数据划分的数量、唯一性和同批次子集无交集检查通过。
- 五种模型实际加载对应权重并推理示例4，Dice与历史逐图记录一致。
- 双模型应用输出轮廓图、肉柱掩码、硬币掩码和CSV，预测面积203.7319 mm²与历史样本一致。
- Python语法、五个训练/评估/应用入口的帮助命令和六份训练启动配置已检查。
- 上传源码包检查本机绝对路径、模型二进制和临时输出，排除临时文件。

| 模型 | 示例4 Dice |
|---|---:|
| U-Net++ | 0.926926 |
| U-Net | 0.915939 |
| DeepLabV3+ | 0.918633 |
| SegFormer-B0 | 0.932810 |
| Mask R-CNN | 0.911222 |

上述为权重加载和推理回归检查，没有重新训练全部模型，也没有在一台全新机器重新安装环境。GUI的交互点击未自动验证；本次已验证GUI共用的批量处理函数。

安装依赖并放置权重后，可复查：

```bash
python tools/check_project.py --all-weights
python tools/smoke_test_models.py --include-detectron2
```

若仅安装语义分割依赖，省略 `--include-detectron2`。
