# 模型与权重对应表

| 仓库内预期路径 | 模型 | 作用 |
|---|---|---|
| `runs/muscle_binary_v1/model_best.pth` | U-Net++ / ResNet34 / 2类 | 最终肉柱模型：背景、肉柱 |
| `runs/unetpp_target_v2/model_best.pth` | U-Net++ / ResNet34 / 3类 | 最终硬币模型：取背景、肉柱、硬币三类中的硬币通道 |
| `runs/comparison_unet_v1/model_best.pth` | U-Net / ResNet34 / 2类 | 对比实验 |
| `runs/comparison_deeplabv3plus_v1/model_best.pth` | DeepLabV3+ / ResNet34 / 2类 | 对比实验 |
| `runs/comparison_segformer_b0_v1/model_best.pth` | SegFormer / MiT-B0 / 2类 | 对比实验 |
| `runs/comparison_detectron2_v1/model_best.pth` | Mask R-CNN / ResNet50-FPN / 1个前景类 | 对比实验 |
| `weights/source_unetpp_pretrained.pth` | 源域U-Net++初始化 | U-Net++兼容参数迁移，U-Net/DeepLabV3+编码器迁移 |

权重独立保存在本地交付目录的 `scallop-model-weights/`，内部目录结构与上表一致。将其中的 `runs/` 与 `weights/` 合并复制到仓库根目录即可。全部七份文件约660 MB，校验值见 `configs/checkpoint_manifest.json`。

仅运行最终应用时复制前两份即可。SegFormer-B0训练使用ImageNet编码器预训练，Mask R-CNN训练使用Detectron2的COCO初始化，首次训练可能需要下载。

代码加载的是PyTorch state_dict；只加载可信来源权重。不要将训练过的权重误标为上游原始预训练模型。当前未自动发布权重，也未填写不存在的下载链接。

```bash
python tools/check_project.py --check-weights
```

默认检查最终两份权重。增加 `--all-weights` 检查七份权重及SHA-256。上传Git源码时 `.gitignore` 会忽略这些二进制文件；如需公开模型，后续单独建立模型下载入口并在本文件填写真实链接。
