"""Verify checkpoint compatibility and sample-4 predictions against archived metrics."""
import argparse
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--weights-root',type=Path,default=ROOT)
    parser.add_argument('--include-detectron2',action='store_true')
    args=parser.parse_args()
    import torch
    import scallop_one_click as app
    from evaluate_blind2 import read_gray, make_tensor, largest_component, dice_iou
    from train_unetpp_target import build_model
    image=read_gray(ROOT/'examples/input/4.png')
    truth=largest_component(read_gray(ROOT/'examples/ground_truth/4_muscle.png'))
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    tensor=make_tensor(image,device)
    specs=[('unetplusplus','muscle_binary_v1','blind2_final_v1'),
           ('unet','comparison_unet_v1','comparison_unet_v1/blind2'),
           ('deeplabv3plus','comparison_deeplabv3plus_v1','comparison_deeplabv3plus_v1/blind2'),
           ('segformer_b0','comparison_segformer_b0_v1','comparison_segformer_b0_v1/blind2')]
    if args.include_detectron2:
        specs.append(('detectron2','comparison_detectron2_v1','comparison_detectron2_v1/blind2'))
    checks=[]
    for architecture,run,report in specs:
        if architecture=='detectron2':
            from detectron2.modeling import build_model as build_detectron
            from train_detectron2_target import make_cfg, predict_muscle
            model=build_detectron(make_cfg(device,0.5))
        else:
            model=build_model(architecture,2,encoder_weights=None)
        model.load_state_dict(torch.load(args.weights_root/'runs'/run/'model_best.pth',map_location='cpu'),strict=True)
        model.to(device).eval()
        with torch.no_grad():
            if architecture=='detectron2':
                mask,_=predict_muscle(model,image,device,0.5)
            else:
                mask=largest_component(model(tensor).argmax(1)[0].cpu().numpy()==1)
        dice,_=dice_iou(mask,truth)
        history=json.loads((ROOT/'runs'/report/'summary.json').read_text(encoding='utf-8'))
        expected=next(r for r in history['rows_sorted_by_muscle_dice'] if r['id']=='4')['muscle_dice']
        if abs(dice-expected)>0.002:
            raise AssertionError(f'{architecture}: Dice {dice} differs from archived {expected}')
        checks.append({'model':architecture,'sample4_dice':dice,'archived_dice':expected})
        print(f'PASS {architecture}: Dice={dice:.6f}',flush=True)
        del model
        if device.type=='cuda':torch.cuda.empty_cache()
    app.MUSCLE_WEIGHTS=args.weights_root/'runs/muscle_binary_v1/model_best.pth'
    app.JOINT_WEIGHTS=args.weights_root/'runs/unetpp_target_v2/model_best.pth'
    output=ROOT/'outputs/smoke_test'
    rows=app.process_files([ROOT/'examples/input/4.png'],output)
    if abs(rows[0]['muscle_area_mm2']-203.7319)>0.1:
        raise AssertionError('Area differs from archived sample-4 result.')
    for p in ['results.csv','visuals/4_result.png','masks/4_muscle.png','masks/4_coin.png']:
        if not (output/p).is_file():raise AssertionError(f'Missing output: {p}')
    (output/'verification.json').write_text(json.dumps({'checks':checks,'application_output':rows},indent=2,ensure_ascii=False),encoding='utf-8')
    print('PASS application outputs and calibrated area.',flush=True)


if __name__=='__main__':
    main()
