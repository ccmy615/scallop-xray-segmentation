"""Check split integrity, optional data files, and checkpoint hashes; no GPU required."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from project_config import load_splits


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-data',action='store_true')
    parser.add_argument('--check-weights',action='store_true')
    parser.add_argument('--all-weights',action='store_true')
    parser.add_argument('--weights-root',type=Path,default=ROOT)
    args=parser.parse_args()
    config=load_splits(ROOT/'configs/splits_v1.json')
    expected={'source':{'train':200,'val':29,'test':28},'target1':{'train':40,'val':10},'blind2':{'locked_test':50}}
    errors=[]
    for name,partitions in expected.items():
        seen=set()
        for partition,count in partitions.items():
            ids=config[name][partition]
            if len(ids)!=count or len(set(ids))!=count or seen.intersection(ids):
                errors.append(f'Invalid IDs/count/overlap: {name}/{partition}')
            seen.update(ids)
        if args.check_data:
            folders=('all_images','all_mmask','all_cmask') if name=='source' else (('50','mmask','cmask') if name=='target1' else ('50X图','mmask','cmask'))
            for stem in seen:
                for folder in folders:
                    path=Path(config[name]['root'])/folder/(stem+'.png')
                    if not path.is_file():
                        errors.append(f'Missing data: {path}')
                    else:
                        # Pillow is brought in by the training dependencies.
                        from PIL import Image
                        with Image.open(path) as im:
                            if im.size != (512,512):
                                errors.append(f'Expected 512x512: {path}')
    if args.check_weights or args.all_weights:
        manifest=json.loads((ROOT/'configs/checkpoint_manifest.json').read_text(encoding='utf-8'))
        for item in manifest:
            relative=item['repository_path']
            if not args.all_weights and not any(x in relative for x in ('muscle_binary_v1','unetpp_target_v2')):
                continue
            path=args.weights_root/relative
            if not path.is_file():
                errors.append(f'Missing checkpoint: {path}')
                continue
            digest=hashlib.sha256()
            with path.open('rb') as f:
                for chunk in iter(lambda:f.read(8*1024*1024),b''):
                    digest.update(chunk)
            if path.stat().st_size!=item['bytes'] or digest.hexdigest()!=item['sha256']:
                errors.append(f'Checkpoint hash mismatch: {relative}')
            else:
                print(f'OK {relative}')
    for error in errors[:20]:
        print(error)
    if errors:
        print(f'FAILED: {len(errors)} findings');return 1
    print('PASS: split integrity and requested checks.');return 0


if __name__=='__main__':
    raise SystemExit(main())
