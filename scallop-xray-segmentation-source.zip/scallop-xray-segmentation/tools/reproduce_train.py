"""Start training from a recorded configuration without overwriting archived runs."""
import argparse
import json
from pathlib import Path
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RUNS = ('muscle_binary_v1', 'unetpp_target_v2', 'comparison_unet_v1',
        'comparison_deeplabv3plus_v1', 'comparison_segformer_b0_v1', 'comparison_detectron2_v1')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', choices=RUNS, required=True)
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--output-dir', type=Path)
    args = parser.parse_args()
    config = json.loads((ROOT/'runs'/args.run/'run_config.json').read_text(encoding='utf-8'))
    script = 'train_detectron2_target.py' if args.run == 'comparison_detectron2_v1' else 'train_unetpp_target.py'
    config['output_dir'] = str(args.output_dir.resolve() if args.output_dir else ROOT/'outputs'/args.run)
    if args.run == 'muscle_binary_v1':
        config.setdefault('task', 'muscle')
        config.setdefault('architecture', 'unetplusplus')
    if args.run == 'unetpp_target_v2':
        config.setdefault('task', 'joint')
        config.setdefault('architecture', 'unetplusplus')
    command = [sys.executable, str(ROOT/script)]
    for key, value in config.items():
        if value is None or value is False:
            continue
        command.append('--'+key.replace('_','-'))
        if value is not True:
            if key in ('splits','initial_weights','output_dir'):
                value = str((ROOT/str(value)).resolve())
            command.append(str(value))
    print(shlex.join(command), flush=True)
    if not args.dry_run:
        out=Path(config['output_dir'])
        if out.exists() and any(out.iterdir()):
            parser.error('Output directory is not empty; choose a new --output-dir.')
        subprocess.run(command, cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
