"""Resolve data roots relative to this repository, independent of working directory."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load_splits(path):
    config = json.loads(Path(path).read_text(encoding='utf-8'))
    for name in ('source', 'target1', 'blind2'):
        root = Path(config[name]['root']).expanduser()
        if not root.is_absolute():
            root = ROOT / root
        config[name]['root'] = str(root.resolve())
    return config
