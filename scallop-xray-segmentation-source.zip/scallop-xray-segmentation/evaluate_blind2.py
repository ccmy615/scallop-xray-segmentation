import argparse
import csv
import json
from pathlib import Path
from project_config import load_splits

import cv2
import numpy as np
import segmentation_models_pytorch as smp
import torch

from train_unetpp_target import build_model


PROJECT_ROOT = Path(__file__).resolve().parent
DEFAULT_SPLITS = PROJECT_ROOT / "configs" / "splits_v1.json"
DEFAULT_MUSCLE = PROJECT_ROOT / "runs" / "muscle_binary_v1" / "model_best.pth"
DEFAULT_JOINT = PROJECT_ROOT / "runs" / "unetpp_target_v2" / "model_best.pth"
DEFAULT_QUALITY_REVIEW = PROJECT_ROOT / "configs" / "blind2_quality_review_v1.json"


def read_gray(path):
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(path)
    return image


def write_image(path, image):
    path = Path(path)
    ok, encoded = cv2.imencode(path.suffix or ".png", image)
    if not ok:
        raise ValueError(f"Cannot encode output image: {path}")
    encoded.tofile(str(path))


def largest_component(mask):
    binary = (mask > 0).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    if count <= 1:
        return binary
    keep = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return (labels == keep).astype(np.uint8)


def dice_iou(pred, truth):
    intersection = int(np.logical_and(pred, truth).sum())
    pred_count = int(pred.sum())
    truth_count = int(truth.sum())
    union = pred_count + truth_count - intersection
    return 2 * intersection / max(pred_count + truth_count, 1), intersection / max(union, 1)


def make_tensor(image, device):
    tensor = torch.from_numpy(image.astype(np.float32) / 255.0).unsqueeze(0).repeat(3, 1, 1)
    tensor = (tensor - 0.5) / 0.5
    return tensor.unsqueeze(0).to(device)


def overlay(image, muscle, coin, area_mm2):
    canvas = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    tint = canvas.copy()
    tint[muscle > 0] = (40, 210, 40)
    tint[coin > 0] = (30, 170, 255)
    canvas = cv2.addWeighted(canvas, 0.68, tint, 0.32, 0)
    for mask, color, label in ((muscle, (40, 255, 40), "muscle"), (coin, (0, 180, 255), "coin")):
        contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(canvas, contours, -1, color, 2)
        if contours:
            x, y, _, _ = cv2.boundingRect(max(contours, key=cv2.contourArea))
            cv2.putText(canvas, label, (x, max(18, y - 7)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)
    cv2.rectangle(canvas, (5, 5), (286, 37), (0, 0, 0), -1)
    cv2.putText(canvas, f"muscle area: {area_mm2:.2f} mm^2", (12, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.58, (255, 255, 255), 2)
    return canvas


def summarize(rows, key):
    values = np.asarray([row[key] for row in rows], dtype=np.float64)
    return {
        "mean": float(values.mean()),
        "median": float(np.median(values)),
        "p05": float(np.quantile(values, 0.05)),
        "p95": float(np.quantile(values, 0.95)),
        "min": float(values.min()),
        "max": float(values.max()),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--splits", type=Path, default=DEFAULT_SPLITS)
    parser.add_argument("--muscle-weights", type=Path, default=DEFAULT_MUSCLE)
    parser.add_argument("--joint-weights", type=Path, default=DEFAULT_JOINT)
    parser.add_argument("--quality-review", type=Path, default=DEFAULT_QUALITY_REVIEW)
    parser.add_argument("--output-dir", type=Path, default=PROJECT_ROOT / "runs" / "blind2_final_v1")
    parser.add_argument(
        "--muscle-architecture",
        choices=("unet", "unetplusplus", "deeplabv3plus", "segformer_b0"),
        default="unetplusplus",
    )
    args = parser.parse_args()

    config = load_splits(args.splits)
    root = Path(config["blind2"]["root"])
    stems = config["blind2"]["locked_test"]
    coin_area = float(config["coin_area_mm2"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    muscle_model = build_model(args.muscle_architecture, 2, encoder_weights=None)
    muscle_model.load_state_dict(torch.load(args.muscle_weights, map_location="cpu"), strict=True)
    muscle_model.to(device).eval()
    joint_model = smp.UnetPlusPlus(encoder_name="resnet34", encoder_weights=None, in_channels=3, classes=3)
    joint_model.load_state_dict(torch.load(args.joint_weights, map_location="cpu"), strict=True)
    joint_model.to(device).eval()

    visuals = args.output_dir / "visuals"
    comparisons = args.output_dir / "comparisons"
    visuals.mkdir(parents=True, exist_ok=True)
    comparisons.mkdir(parents=True, exist_ok=True)
    rows = []

    with torch.no_grad():
        for stem in stems:
            image = read_gray(root / "50X图" / f"{stem}.png")
            tensor = make_tensor(image, device)
            muscle = largest_component(muscle_model(tensor).argmax(1).squeeze(0).cpu().numpy() == 1)
            joint = joint_model(tensor).argmax(1).squeeze(0).cpu().numpy()
            coin = largest_component(joint == 2)
            true_muscle = largest_component(read_gray(root / "mmask" / f"{stem}.png"))
            true_coin = largest_component(read_gray(root / "cmask" / f"{stem}.png"))

            muscle_dice, muscle_iou = dice_iou(muscle, true_muscle)
            coin_dice, coin_iou = dice_iou(coin, true_coin)
            pred_area = float(muscle.sum()) / max(float(coin.sum()), 1.0) * coin_area
            true_area = float(true_muscle.sum()) / max(float(true_coin.sum()), 1.0) * coin_area
            abs_error = abs(pred_area - true_area)
            rel_error = abs_error / max(true_area, 1e-8)
            rows.append({
                "id": stem,
                "muscle_dice": muscle_dice,
                "muscle_iou": muscle_iou,
                "coin_dice": coin_dice,
                "coin_iou": coin_iou,
                "muscle_pixels_pred": int(muscle.sum()),
                "muscle_pixels_true": int(true_muscle.sum()),
                "coin_pixels_pred": int(coin.sum()),
                "coin_pixels_true": int(true_coin.sum()),
                "area_pred_mm2": pred_area,
                "area_true_mm2": true_area,
                "area_absolute_error_mm2": abs_error,
                "area_relative_error": rel_error,
            })

            pred_visual = overlay(image, muscle, coin, pred_area)
            true_visual = overlay(image, true_muscle, true_coin, true_area)
            write_image(visuals / f"{stem}.png", pred_visual)
            comparison = np.concatenate([pred_visual, true_visual], axis=1)
            cv2.putText(comparison, "PREDICTION", (305, 62), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (255, 255, 255), 2)
            cv2.putText(comparison, "GROUND TRUTH", (817, 62), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (255, 255, 255), 2)
            write_image(comparisons / f"{stem}.png", comparison)

    fieldnames = list(rows[0].keys())
    with (args.output_dir / "per_image_metrics.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    summary = {
        "protocol": "single locked blind evaluation; all 50 images included",
        "muscle_architecture": args.muscle_architecture,
        "count": len(rows),
        "muscle_dice": summarize(rows, "muscle_dice"),
        "muscle_iou": summarize(rows, "muscle_iou"),
        "coin_dice": summarize(rows, "coin_dice"),
        "coin_iou": summarize(rows, "coin_iou"),
        "area_absolute_error_mm2": summarize(rows, "area_absolute_error_mm2"),
        "area_relative_error": summarize(rows, "area_relative_error"),
        "rows_sorted_by_muscle_dice": sorted(rows, key=lambda row: row["muscle_dice"]),
    }
    if args.quality_review.exists():
        review = json.loads(args.quality_review.read_text(encoding="utf-8"))
        excluded_ids = set(review.get("excluded_candidates", {}))
        sensitivity_rows = [row for row in rows if row["id"] not in excluded_ids]
        summary["sensitivity_analysis"] = {
            "status": review.get("status"),
            "use": review.get("use"),
            "excluded_candidates": review.get("excluded_candidates"),
            "count": len(sensitivity_rows),
            "muscle_dice": summarize(sensitivity_rows, "muscle_dice"),
            "muscle_iou": summarize(sensitivity_rows, "muscle_iou"),
            "coin_dice": summarize(sensitivity_rows, "coin_dice"),
            "coin_iou": summarize(sensitivity_rows, "coin_iou"),
            "area_absolute_error_mm2": summarize(sensitivity_rows, "area_absolute_error_mm2"),
            "area_relative_error": summarize(sensitivity_rows, "area_relative_error"),
        }
    (args.output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in summary.items() if key != "rows_sorted_by_muscle_dice"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
