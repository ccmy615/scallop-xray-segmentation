import argparse
import json
import math
import random
import time
from pathlib import Path
from project_config import load_splits

import cv2
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from detectron2 import model_zoo
from detectron2.checkpoint import DetectionCheckpointer
from detectron2.config import get_cfg
from detectron2.modeling import build_model
from detectron2.structures import BitMasks, Instances
from detectron2.utils.events import EventStorage

from train_unetpp_target import JointAugment, entries_from_split, largest_component, load_example


PROJECT_ROOT = Path(__file__).resolve().parent
DEFAULT_SPLITS = PROJECT_ROOT / "configs" / "splits_v1.json"


class DetectronScallopDataset(Dataset):
    def __init__(self, entries, augment=False):
        self.entries = entries
        self.augment = JointAugment(augment)

    def __len__(self):
        return len(self.entries)

    def __getitem__(self, index):
        dataset_name, root, stem = self.entries[index]
        image, muscle, coin = load_example(dataset_name, root, stem)
        image, muscle, _ = self.augment(image, muscle, np.zeros_like(coin))
        height, width = image.shape
        image_tensor = torch.from_numpy(np.repeat(image[:, :, None], 3, axis=2).transpose(2, 0, 1).copy())
        masks = BitMasks(torch.from_numpy((muscle > 0)[None, :, :]))
        instances = Instances((height, width))
        instances.gt_classes = torch.zeros(1, dtype=torch.int64)
        instances.gt_masks = masks
        instances.gt_boxes = masks.get_bounding_boxes()
        return {
            "image": image_tensor,
            "height": height,
            "width": width,
            "instances": instances,
            "identifier": f"{dataset_name}:{stem}",
        }


def collate(batch):
    return batch


def make_cfg(device, score_threshold):
    cfg = get_cfg()
    config_name = "COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml"
    cfg.merge_from_file(model_zoo.get_config_file(config_name))
    cfg.MODEL.WEIGHTS = model_zoo.get_checkpoint_url(config_name)
    cfg.MODEL.DEVICE = str(device)
    cfg.MODEL.ROI_HEADS.NUM_CLASSES = 1
    cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = score_threshold
    cfg.MODEL.ROI_HEADS.BATCH_SIZE_PER_IMAGE = 128
    cfg.MODEL.ROI_MASK_HEAD.CLS_AGNOSTIC_MASK = False
    cfg.TEST.DETECTIONS_PER_IMAGE = 3
    cfg.INPUT.MIN_SIZE_TRAIN = (512,)
    cfg.INPUT.MAX_SIZE_TRAIN = 512
    cfg.INPUT.MIN_SIZE_TEST = 512
    cfg.INPUT.MAX_SIZE_TEST = 512
    cfg.INPUT.FORMAT = "RGB"
    return cfg


def predict_muscle(model, image, device, score_threshold):
    tensor = torch.from_numpy(np.repeat(image[:, :, None], 3, axis=2).transpose(2, 0, 1).copy()).to(device)
    with torch.no_grad():
        instances = model([{"image": tensor, "height": image.shape[0], "width": image.shape[1]}])[0][
            "instances"
        ].to("cpu")
    if len(instances) == 0:
        return np.zeros(image.shape, dtype=np.uint8), 0.0
    keep = instances.scores >= score_threshold
    instances = instances[keep]
    if len(instances) == 0:
        return np.zeros(image.shape, dtype=np.uint8), 0.0
    best = int(torch.argmax(instances.scores).item())
    mask = largest_component(instances.pred_masks[best].numpy().astype(np.uint8))
    return mask, float(instances.scores[best].item())


def dice_iou(prediction, truth):
    pred = prediction > 0
    true = truth > 0
    intersection = int(np.logical_and(pred, true).sum())
    union = int(np.logical_or(pred, true).sum())
    return (
        2.0 * intersection / max(int(pred.sum()) + int(true.sum()), 1),
        intersection / max(union, 1),
    )


def evaluate(model, entries, device, score_threshold):
    model.eval()
    rows = []
    for dataset_name, root, stem in entries:
        image, muscle, _ = load_example(dataset_name, root, stem)
        prediction, score = predict_muscle(model, image, device, score_threshold)
        dice, iou = dice_iou(prediction, muscle)
        rows.append(
            {
                "id": f"{dataset_name}:{stem}",
                "muscle_dice": dice,
                "muscle_iou": iou,
                "muscle_pixels_pred": int(prediction.sum()),
                "muscle_pixels_true": int(muscle.sum()),
                "instance_score": score,
            }
        )
    summary = {}
    for key in ("muscle_dice", "muscle_iou"):
        values = np.asarray([row[key] for row in rows], dtype=np.float64)
        summary[f"{key}_mean"] = float(values.mean())
        summary[f"{key}_median"] = float(np.median(values))
        summary[f"{key}_p95"] = float(np.quantile(values, 0.95))
    return summary, rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--splits", type=Path, default=DEFAULT_SPLITS)
    parser.add_argument("--output-dir", type=Path, default=PROJECT_ROOT / "runs" / "comparison_detectron2_v1")
    parser.add_argument("--epochs", type=int, default=35)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--learning-rate", type=float, default=5e-5)
    parser.add_argument("--patience", type=int, default=9)
    parser.add_argument("--target-repeat", type=int, default=3)
    parser.add_argument("--seed", type=int, default=20260906)
    parser.add_argument("--score-threshold", type=float, default=0.5)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)

    split_config = load_splits(args.splits)
    source_train, source_val, source_test, target_train, target_val = entries_from_split(split_config)
    train_entries = source_train + target_train * args.target_repeat
    train_loader = DataLoader(
        DetectronScallopDataset(train_entries, augment=True),
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
        collate_fn=collate,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cfg = make_cfg(device, args.score_threshold)
    model = build_model(cfg)
    DetectionCheckpointer(model).load(cfg.MODEL.WEIGHTS)
    model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", factor=0.5, patience=3)
    scaler = torch.cuda.amp.GradScaler(enabled=device.type == "cuda")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    history_path = args.output_dir / "history.jsonl"
    best_path = args.output_dir / "model_best.pth"
    last_path = args.output_dir / "model_last.pth"
    best_score = -1.0
    stale_epochs = 0

    with history_path.open("w", encoding="utf-8") as history_file:
        for epoch in range(1, args.epochs + 1):
            started = time.time()
            model.train()
            losses = []
            for batch in train_loader:
                optimizer.zero_grad(set_to_none=True)
                with EventStorage():
                    with torch.cuda.amp.autocast(enabled=device.type == "cuda"):
                        loss_dict = model(batch)
                        loss = sum(loss_dict.values())
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                scaler.step(optimizer)
                scaler.update()
                losses.append(float(loss.item()))

            source_summary, _ = evaluate(model, source_val, device, args.score_threshold)
            target_summary, _ = evaluate(model, target_val, device, args.score_threshold)
            selection_score = target_summary["muscle_dice_mean"]
            scheduler.step(selection_score)
            record = {
                "epoch": epoch,
                "train_loss": float(np.mean(losses)),
                "learning_rate": optimizer.param_groups[0]["lr"],
                "selection_score": selection_score,
                "source_val": source_summary,
                "target_val": target_summary,
                "elapsed_seconds": time.time() - started,
            }
            history_file.write(json.dumps(record, ensure_ascii=False) + "\n")
            history_file.flush()
            print(json.dumps(record, ensure_ascii=False), flush=True)
            if selection_score > best_score + 1e-5:
                best_score = selection_score
                stale_epochs = 0
                torch.save(model.state_dict(), best_path)
            else:
                stale_epochs += 1
            if stale_epochs >= args.patience:
                break

    torch.save(model.state_dict(), last_path)
    model.load_state_dict(torch.load(best_path, map_location=device), strict=True)
    source_test_summary, source_test_rows = evaluate(model, source_test, device, args.score_threshold)
    target_val_summary, target_val_rows = evaluate(model, target_val, device, args.score_threshold)
    report = {
        "architecture": "detectron2_mask_rcnn_r50_fpn",
        "best_selection_score": best_score,
        "source_test": source_test_summary,
        "target1_validation": target_val_summary,
        "source_test_rows": source_test_rows,
        "target1_validation_rows": target_val_rows,
        "blind2_evaluated": False,
    }
    (args.output_dir / "evaluation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (args.output_dir / "run_config.json").write_text(
        json.dumps(vars(args), default=str, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
