import argparse
import csv
import json
import time
from pathlib import Path
from project_config import load_splits

import cv2
import numpy as np
import torch
from detectron2.modeling import build_model as build_detectron_model

from evaluate_blind2 import dice_iou, largest_component, make_tensor, overlay, read_gray, summarize, write_image
from train_detectron2_target import make_cfg, predict_muscle
from train_unetpp_target import build_model as build_semantic_model


PROJECT_ROOT = Path(__file__).resolve().parent
DEFAULT_SPLITS = PROJECT_ROOT / "configs" / "splits_v1.json"
DEFAULT_MUSCLE = PROJECT_ROOT / "runs" / "comparison_detectron2_v1" / "model_best.pth"
DEFAULT_JOINT = PROJECT_ROOT / "runs" / "unetpp_target_v2" / "model_best.pth"
DEFAULT_QUALITY_REVIEW = PROJECT_ROOT / "configs" / "blind2_quality_review_v1.json"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--splits", type=Path, default=DEFAULT_SPLITS)
    parser.add_argument("--muscle-weights", type=Path, default=DEFAULT_MUSCLE)
    parser.add_argument("--joint-weights", type=Path, default=DEFAULT_JOINT)
    parser.add_argument("--quality-review", type=Path, default=DEFAULT_QUALITY_REVIEW)
    parser.add_argument(
        "--output-dir", type=Path, default=PROJECT_ROOT / "runs" / "comparison_detectron2_v1" / "blind2"
    )
    parser.add_argument("--score-threshold", type=float, default=0.5)
    args = parser.parse_args()

    config = load_splits(args.splits)
    root = Path(config["blind2"]["root"])
    stems = config["blind2"]["locked_test"]
    coin_area = float(config["coin_area_mm2"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    d2_cfg = make_cfg(device, args.score_threshold)
    muscle_model = build_detectron_model(d2_cfg)
    muscle_model.load_state_dict(torch.load(args.muscle_weights, map_location="cpu"), strict=True)
    muscle_model.to(device).eval()
    joint_model = build_semantic_model("unetplusplus", 3, encoder_weights=None)
    joint_model.load_state_dict(torch.load(args.joint_weights, map_location="cpu"), strict=True)
    joint_model.to(device).eval()

    visuals = args.output_dir / "visuals"
    comparisons = args.output_dir / "comparisons"
    visuals.mkdir(parents=True, exist_ok=True)
    comparisons.mkdir(parents=True, exist_ok=True)
    rows = []
    inference_times = []

    with torch.no_grad():
        for stem in stems:
            image = read_gray(root / "50X图" / f"{stem}.png")
            if device.type == "cuda":
                torch.cuda.synchronize()
            started = time.perf_counter()
            muscle, instance_score = predict_muscle(
                muscle_model, image, device, args.score_threshold
            )
            if device.type == "cuda":
                torch.cuda.synchronize()
            inference_times.append((time.perf_counter() - started) * 1000.0)
            tensor = make_tensor(image, device)
            joint = joint_model(tensor).argmax(1).squeeze(0).cpu().numpy()
            coin = largest_component(joint == 2)
            true_muscle = largest_component(read_gray(root / "mmask" / f"{stem}.png"))
            true_coin = largest_component(read_gray(root / "cmask" / f"{stem}.png"))

            muscle_dice, muscle_iou = dice_iou(muscle, true_muscle)
            coin_dice, coin_iou = dice_iou(coin, true_coin)
            pred_area = float(muscle.sum()) / max(float(coin.sum()), 1.0) * coin_area
            true_area = float(true_muscle.sum()) / max(float(true_coin.sum()), 1.0) * coin_area
            abs_error = abs(pred_area - true_area)
            rel_error = abs_error / max(true_area, 1e-8)
            rows.append(
                {
                    "id": stem,
                    "muscle_dice": muscle_dice,
                    "muscle_iou": muscle_iou,
                    "coin_dice": coin_dice,
                    "coin_iou": coin_iou,
                    "muscle_pixels_pred": int(muscle.sum()),
                    "muscle_pixels_true": int(true_muscle.sum()),
                    "coin_pixels_pred": int(coin.sum()),
                    "coin_pixels_true": int(true_coin.sum()),
                    "area_pred_mm2": pred_area,
                    "area_true_mm2": true_area,
                    "area_absolute_error_mm2": abs_error,
                    "area_relative_error": rel_error,
                    "instance_score": instance_score,
                }
            )

            pred_visual = overlay(image, muscle, coin, pred_area)
            true_visual = overlay(image, true_muscle, true_coin, true_area)
            write_image(visuals / f"{stem}.png", pred_visual)
            write_image(comparisons / f"{stem}.png", np.concatenate([pred_visual, true_visual], axis=1))

    with (args.output_dir / "per_image_metrics.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    summary = {
        "protocol": "single locked blind evaluation; all 50 images included",
        "muscle_architecture": "detectron2_mask_rcnn_r50_fpn",
        "score_threshold": args.score_threshold,
        "count": len(rows),
        "muscle_dice": summarize(rows, "muscle_dice"),
        "muscle_iou": summarize(rows, "muscle_iou"),
        "coin_dice": summarize(rows, "coin_dice"),
        "coin_iou": summarize(rows, "coin_iou"),
        "area_absolute_error_mm2": summarize(rows, "area_absolute_error_mm2"),
        "area_relative_error": summarize(rows, "area_relative_error"),
        "muscle_inference_ms": {
            "mean": float(np.mean(inference_times)),
            "median": float(np.median(inference_times)),
            "p95": float(np.quantile(inference_times, 0.95)),
        },
        "rows_sorted_by_muscle_dice": sorted(rows, key=lambda row: row["muscle_dice"]),
    }
    if args.quality_review.exists():
        review = json.loads(args.quality_review.read_text(encoding="utf-8"))
        excluded_ids = set(review.get("excluded_candidates", {}))
        sensitivity_rows = [row for row in rows if row["id"] not in excluded_ids]
        summary["sensitivity_analysis"] = {
            "status": review.get("status"),
            "use": review.get("use"),
            "excluded_candidates": review.get("excluded_candidates"),
            "count": len(sensitivity_rows),
            "muscle_dice": summarize(sensitivity_rows, "muscle_dice"),
            "muscle_iou": summarize(sensitivity_rows, "muscle_iou"),
            "coin_dice": summarize(sensitivity_rows, "coin_dice"),
            "coin_iou": summarize(sensitivity_rows, "coin_iou"),
            "area_absolute_error_mm2": summarize(sensitivity_rows, "area_absolute_error_mm2"),
            "area_relative_error": summarize(sensitivity_rows, "area_relative_error"),
        }
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {key: value for key, value in summary.items() if key != "rows_sorted_by_muscle_dice"},
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
